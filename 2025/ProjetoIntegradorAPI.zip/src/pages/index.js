const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();
const PORT = 3000;

app.use(express.json()); // para tratar JSON no body das requisições

// Funções utilitárias para ler e escrever os arquivos JSON
function readData(file) {
  // Ajustado para acessar a pasta "data" a partir do diretório atual (pages)
  const filePath = path.join(__dirname, '..', 'data', file);
  if (!fs.existsSync(filePath)) {
    return [];
  }
  const data = fs.readFileSync(filePath);
  return JSON.parse(data);
}

function writeData(file, data) {
  // Ajustado para acessar a pasta "data" a partir do diretório atual (pages)
  const filePath = path.join(__dirname, '..', 'data', file);
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}

// Middleware de autenticação simples
// Usa um header "employeeid" para identificar o funcionário logado
function authMiddleware(req, res, next) {
  const employeeId = req.headers.employeeid;
  if (!employeeId) {
    return res.status(401).json({ message: 'Não autorizado. Falta o header "employeeid".' });
  }
  const funcionarios = readData('funcionarios.json');
  const funcionario = funcionarios.find(f => String(f.id) === String(employeeId));
  if (!funcionario) {
    return res.status(401).json({ message: 'Funcionário não encontrado.' });
  }
  req.employee = funcionario;
  next();
}

// Endpoint de Login para funcionários
app.post('/login', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ message: 'Username e password são obrigatórios.' });
  }
  const funcionarios = readData('funcionarios.json');
  const funcionario = funcionarios.find(f => f.username === username && f.password === password);
  if (!funcionario) {
    return res.status(401).json({ message: 'Credenciais inválidas.' });
  }
  // Retorna a identificação do funcionário, que deve ser enviado no header "employeeid" nas demais requisições
  return res.json({ message: 'Login realizado com sucesso.', employeeId: funcionario.id });
});


// --------- CRUD para Clientes ---------

// Listar todos os clientes
app.get('/clientes', authMiddleware, (req, res) => {
  const clientes = readData('clientes.json');
  res.json(clientes);
});

// Cadastrar um novo cliente
app.post('/clientes', authMiddleware, (req, res) => {
  const { nome, email } = req.body;
  if (!nome || !email) {
    return res.status(400).json({ message: 'Nome e email são obrigatórios.' });
  }
  let clientes = readData('clientes.json');
  const newCliente = {
    id: Date.now(), // id simples baseado na data
    nome,
    email
  };
  clientes.push(newCliente);
  writeData('clientes.json', clientes);
  res.status(201).json(newCliente);
});

// Obter detalhes de um cliente
app.get('/clientes/:id', authMiddleware, (req, res) => {
  const clientes = readData('clientes.json');
  const cliente = clientes.find(c => String(c.id) === req.params.id);
  if (!cliente) {
    return res.status(404).json({ message: 'Cliente não encontrado.' });
  }
  res.json(cliente);
});

// Atualizar um cliente
app.put('/clientes/:id', authMiddleware, (req, res) => {
  let clientes = readData('clientes.json');
  const index = clientes.findIndex(c => String(c.id) === req.params.id);
  if (index === -1) {
    return res.status(404).json({ message: 'Cliente não encontrado.' });
  }
  const { nome, email } = req.body;
  if (nome) clientes[index].nome = nome;
  if (email) clientes[index].email = email;
  writeData('clientes.json', clientes);
  res.json(clientes[index]);
});

// Remover um cliente (e seus cartões associados)
app.delete('/clientes/:id', authMiddleware, (req, res) => {
  let clientes = readData('clientes.json');
  const cliente = clientes.find(c => String(c.id) === req.params.id);
  if (!cliente) {
    return res.status(404).json({ message: 'Cliente não encontrado.' });
  }
  clientes = clientes.filter(c => String(c.id) !== req.params.id);
  writeData('clientes.json', clientes);

  // Remove também os cartões associados a este cliente
  let cartoes = readData('cartoes.json');
  cartoes = cartoes.filter(card => String(card.clienteId) !== req.params.id);
  writeData('cartoes.json', cartoes);

  res.json({ message: 'Cliente e cartões associados removidos.' });
});

// --------- CRUD para Cartões ---------
// Cada cartão está vinculado a um cliente (cartão pode ter apenas 1 cliente)

app.get('/clientes/:clienteId/cartoes', authMiddleware, (req, res) => {
  const cartoes = readData('cartoes.json');
  const cardsCliente = cartoes.filter(card => String(card.clienteId) === req.params.clienteId);
  res.json(cardsCliente);
});

// Cadastrar um novo cartão para um cliente específico
app.post('/clientes/:clienteId/cartoes', authMiddleware, (req, res) => {
  const { numero, validade, cvv } = req.body;
  if (!numero || !validade || !cvv) {
    return res.status(400).json({ message: 'Número, validade e CVV são obrigatórios.' });
  }
  // Verifica se o cliente existe
  const clientes = readData('clientes.json');
  const cliente = clientes.find(c => String(c.id) === req.params.clienteId);
  if (!cliente) {
    return res.status(404).json({ message: 'Cliente não encontrado para associar o cartão.' });
  }
  let cartoes = readData('cartoes.json');
  const newCartao = {
    id: Date.now(), // id simples
    clienteId: req.params.clienteId,
    numero,
    validade,
    cvv
  };
  cartoes.push(newCartao);
  writeData('cartoes.json', cartoes);
  res.status(201).json(newCartao);
});

// Obter detalhes de um cartão específico de um cliente
app.get('/clientes/:clienteId/cartoes/:id', authMiddleware, (req, res) => {
  const cartoes = readData('cartoes.json');
  const cartao = cartoes.find(card =>
    String(card.id) === req.params.id &&
    String(card.clienteId) === req.params.clienteId
  );
  if (!cartao) {
    return res.status(404).json({ message: 'Cartão não encontrado.' });
  }
  res.json(cartao);
});

// Atualizar dados de um cartão
app.put('/clientes/:clienteId/cartoes/:id', authMiddleware, (req, res) => {
  let cartoes = readData('cartoes.json');
  const index = cartoes.findIndex(card =>
    String(card.id) === req.params.id &&
    String(card.clienteId) === req.params.clienteId
  );
  if (index === -1) {
    return res.status(404).json({ message: 'Cartão não encontrado.' });
  }
  const { numero, validade, cvv } = req.body;
  if (numero) cartoes[index].numero = numero;
  if (validade) cartoes[index].validade = validade;
  if (cvv) cartoes[index].cvv = cvv;
  writeData('cartoes.json', cartoes);
  res.json(cartoes[index]);
});

// Remover um cartão
app.delete('/clientes/:clienteId/cartoes/:id', authMiddleware, (req, res) => {
  let cartoes = readData('cartoes.json');
  const cartao = cartoes.find(card =>
    String(card.id) === req.params.id &&
    String(card.clienteId) === req.params.clienteId
  );
  if (!cartao) {
    return res.status(404).json({ message: 'Cartão não encontrado.' });
  }
  cartoes = cartoes.filter(card => String(card.id) !== req.params.id);
  writeData('cartoes.json', cartoes);
  res.json({ message: 'Cartão removido.' });
});

app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});
