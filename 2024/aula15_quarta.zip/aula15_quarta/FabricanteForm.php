<?php
include 'dao/ConnectionFactory.php';
include 'dao/FabricanteDao.php';
include 'model/Fabricante.php';

include 'view/fabricante.php';
?>